// Three.js Scene Setup
let scene, camera, renderer;
let heroParticles = [];
let skillsGeometry;
let contactSphere;

// Initialize Three.js
function initThreeJS() {
    // Hero Section Three.js
    initHeroScene();
    
    // Skills Section Three.js
    initSkillsScene();
    
    // Contact Section Three.js
    initContactScene();
    
    // Start animation loop
    animate();
}

// Hero Section Three.js Setup
function initHeroScene() {
    const canvas = document.getElementById('hero-canvas');
    if (!canvas) return;
    
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, canvas.clientWidth / canvas.clientHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true });
    
    renderer.setSize(canvas.clientWidth, canvas.clientHeight);
    renderer.setClearColor(0x000000, 0);
    
    // Create floating particles
    const particleGeometry = new THREE.BufferGeometry();
    const particleCount = 100;
    const positions = new Float32Array(particleCount * 3);
    
    for (let i = 0; i < particleCount * 3; i++) {
        positions[i] = (Math.random() - 0.5) * 10;
    }
    
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    
    const particleMaterial = new THREE.PointsMaterial({
        color: 0x64ffda,
        size: 0.05,
        transparent: true,
        opacity: 0.8
    });
    
    const particles = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particles);
    
    // Create geometric shapes
    const geometries = [
        new THREE.BoxGeometry(0.5, 0.5, 0.5),
        new THREE.SphereGeometry(0.3, 16, 16),
        new THREE.ConeGeometry(0.3, 0.6, 8)
    ];
    
    const material = new THREE.MeshBasicMaterial({
        color: 0x64ffda,
        wireframe: true,
        transparent: true,
        opacity: 0.6
    });
    
    for (let i = 0; i < 5; i++) {
        const geometry = geometries[Math.floor(Math.random() * geometries.length)];
        const mesh = new THREE.Mesh(geometry, material);
        
        mesh.position.set(
            (Math.random() - 0.5) * 8,
            (Math.random() - 0.5) * 6,
            (Math.random() - 0.5) * 4
        );
        
        mesh.rotation.set(
            Math.random() * Math.PI,
            Math.random() * Math.PI,
            Math.random() * Math.PI
        );
        
        heroParticles.push(mesh);
        scene.add(mesh);
    }
    
    camera.position.z = 5;
    
    // Store references for animation
    canvas.scene = scene;
    canvas.camera = camera;
    canvas.renderer = renderer;
    canvas.particles = particles;
    canvas.heroParticles = heroParticles;
}

// Skills Section Three.js Setup
function initSkillsScene() {
    const canvas = document.getElementById('skills-canvas');
    if (!canvas) return;
    
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, canvas.clientWidth / canvas.clientHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true });
    
    renderer.setSize(canvas.clientWidth, canvas.clientHeight);
    renderer.setClearColor(0x000000, 0);
    
    // Create rotating skill icons (represented as geometric shapes)
    const skills = [
        { name: 'Python', color: 0x3776ab, geometry: new THREE.SphereGeometry(0.3, 16, 16) },
        { name: 'JavaScript', color: 0xf7df1e, geometry: new THREE.BoxGeometry(0.4, 0.4, 0.4) },
        { name: 'React', color: 0x61dafb, geometry: new THREE.ConeGeometry(0.3, 0.6, 8) },
        { name: 'Node.js', color: 0x339933, geometry: new THREE.OctahedronGeometry(0.3) },
        { name: 'AI/ML', color: 0xff6b6b, geometry: new THREE.TetrahedronGeometry(0.4) }
    ];
    
    skills.forEach((skill, index) => {
        const material = new THREE.MeshBasicMaterial({
            color: skill.color,
            wireframe: true,
            transparent: true,
            opacity: 0.7
        });
        
        const mesh = new THREE.Mesh(skill.geometry, material);
        
        const angle = (index / skills.length) * Math.PI * 2;
        const radius = 2;
        
        mesh.position.set(
            Math.cos(angle) * radius,
            Math.sin(angle) * radius,
            0
        );
        
        scene.add(mesh);
    });
    
    camera.position.z = 5;
    
    // Store references
    canvas.scene = scene;
    canvas.camera = camera;
    canvas.renderer = renderer;
}

// Contact Section Three.js Setup
function initContactScene() {
    const canvas = document.getElementById('contact-canvas');
    if (!canvas) return;
    
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, canvas.clientWidth / canvas.clientHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true });
    
    renderer.setSize(canvas.clientWidth, canvas.clientHeight);
    renderer.setClearColor(0x000000, 0);
    
    // Create pulsating sphere
    const geometry = new THREE.SphereGeometry(1, 32, 32);
    const material = new THREE.MeshBasicMaterial({
        color: 0x64ffda,
        wireframe: true,
        transparent: true,
        opacity: 0.5
    });
    
    contactSphere = new THREE.Mesh(geometry, material);
    scene.add(contactSphere);
    
    // Add orbiting particles
    const particleGeometry = new THREE.BufferGeometry();
    const particleCount = 50;
    const positions = new Float32Array(particleCount * 3);
    
    for (let i = 0; i < particleCount; i++) {
        const angle = (i / particleCount) * Math.PI * 2;
        const radius = 2 + Math.random() * 0.5;
        
        positions[i * 3] = Math.cos(angle) * radius;
        positions[i * 3 + 1] = (Math.random() - 0.5) * 2;
        positions[i * 3 + 2] = Math.sin(angle) * radius;
    }
    
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    
    const particleMaterial = new THREE.PointsMaterial({
        color: 0x64ffda,
        size: 0.1,
        transparent: true,
        opacity: 0.8
    });
    
    const particles = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particles);
    
    camera.position.z = 5;
    
    // Store references
    canvas.scene = scene;
    canvas.camera = camera;
    canvas.renderer = renderer;
    canvas.contactSphere = contactSphere;
    canvas.particles = particles;
}

// Animation Loop
function animate() {
    requestAnimationFrame(animate);
    
    // Animate Hero Section
    const heroCanvas = document.getElementById('hero-canvas');
    if (heroCanvas && heroCanvas.scene) {
        // Rotate particles
        if (heroCanvas.particles) {
            heroCanvas.particles.rotation.y += 0.002;
        }
        
        // Animate geometric shapes
        if (heroCanvas.heroParticles) {
            heroCanvas.heroParticles.forEach((particle, index) => {
                particle.rotation.x += 0.01;
                particle.rotation.y += 0.01;
                particle.position.y += Math.sin(Date.now() * 0.001 + index) * 0.002;
            });
        }
        
        heroCanvas.renderer.render(heroCanvas.scene, heroCanvas.camera);
    }
    
    // Animate Skills Section
    const skillsCanvas = document.getElementById('skills-canvas');
    if (skillsCanvas && skillsCanvas.scene) {
        skillsCanvas.scene.children.forEach((child, index) => {
            if (child.type === 'Mesh') {
                child.rotation.x += 0.01;
                child.rotation.y += 0.01;
                child.position.y += Math.sin(Date.now() * 0.001 + index) * 0.001;
            }
        });
        
        skillsCanvas.renderer.render(skillsCanvas.scene, skillsCanvas.camera);
    }
    
    // Animate Contact Section
    const contactCanvas = document.getElementById('contact-canvas');
    if (contactCanvas && contactCanvas.scene) {
        if (contactCanvas.contactSphere) {
            contactCanvas.contactSphere.rotation.y += 0.005;
            contactCanvas.contactSphere.scale.setScalar(1 + Math.sin(Date.now() * 0.003) * 0.1);
        }
        
        if (contactCanvas.particles) {
            contactCanvas.particles.rotation.y += 0.002;
        }
        
        contactCanvas.renderer.render(contactCanvas.scene, contactCanvas.camera);
    }
}

// Smooth Scrolling
function initSmoothScrolling() {
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                targetSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Mobile Navigation
function initMobileNav() {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });
    
    // Close menu when clicking on a link
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });
}

// Animated Statistics
function animateStats() {
    const stats = document.querySelectorAll('.stat-number');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const target = parseFloat(entry.target.dataset.target);
                animateNumber(entry.target, 0, target, 2000);
                observer.unobserve(entry.target);
            }
        });
    });
    
    stats.forEach(stat => observer.observe(stat));
}

function animateNumber(element, start, end, duration) {
    const startTime = performance.now();
    
    function update(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        const current = start + (end - start) * easeOutCubic(progress);
        element.textContent = current.toFixed(2);
        
        if (progress < 1) {
            requestAnimationFrame(update);
        }
    }
    
    requestAnimationFrame(update);
}

function easeOutCubic(t) {
    return 1 - Math.pow(1 - t, 3);
}

// Skill Bar Animations
function animateSkillBars() {
    const skillBars = document.querySelectorAll('.skill-progress');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const width = entry.target.dataset.width;
                entry.target.style.width = width;
                observer.unobserve(entry.target);
            }
        });
    });
    
    skillBars.forEach(bar => observer.observe(bar));
}

// Scroll Animations
function initScrollAnimations() {
    const animatedElements = document.querySelectorAll('.section-title, .project-card, .cert-card, .timeline-item');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    animatedElements.forEach(el => observer.observe(el));
}

// Active Navigation
function initActiveNav() {
    const sections = document.querySelectorAll('section');
    const navLinks = document.querySelectorAll('.nav-link');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const id = entry.target.getAttribute('id');
                navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === `#${id}`) {
                        link.classList.add('active');
                    }
                });
            }
        });
    }, {
        threshold: 0.3
    });
    
    sections.forEach(section => observer.observe(section));
}

// Contact Form
function initContactForm() {
    const form = document.getElementById('contactForm');
    
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(form);
        const data = Object.fromEntries(formData);
        
        // Simulate form submission
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        
        submitBtn.textContent = 'Sending...';
        submitBtn.disabled = true;
        
        setTimeout(() => {
            alert('Thank you for your message! I\'ll get back to you soon.');
            form.reset();
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }, 2000);
    });
}

// Resize Handler
function handleResize() {
    const canvases = ['hero-canvas', 'skills-canvas', 'contact-canvas'];
    
    canvases.forEach(canvasId => {
        const canvas = document.getElementById(canvasId);
        if (canvas && canvas.renderer && canvas.camera) {
            const width = canvas.clientWidth;
            const height = canvas.clientHeight;
            
            canvas.renderer.setSize(width, height);
            canvas.camera.aspect = width / height;
            canvas.camera.updateProjectionMatrix();
        }
    });
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initThreeJS();
    initSmoothScrolling();
    initMobileNav();
    animateStats();
    animateSkillBars();
    initScrollAnimations();
    initActiveNav();
    initContactForm();
    
    // Handle window resize
    window.addEventListener('resize', handleResize);
});

// Scroll indicator
window.addEventListener('scroll', () => {
    const scrollIndicator = document.querySelector('.scroll-indicator');
    if (scrollIndicator) {
        const scrolled = window.pageYOffset;
        const rate = scrolled * -0.5;
        scrollIndicator.style.transform = `translateY(${rate}px)`;
        
        if (scrolled > 100) {
            scrollIndicator.style.opacity = '0';
        } else {
            scrollIndicator.style.opacity = '1';
        }
    }
});

