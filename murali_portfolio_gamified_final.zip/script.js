// Gamified Portfolio JavaScript
class GamePortfolio {
    constructor() {
        this.xp = 0;
        this.explorationProgress = 0;
        this.achievements = {
            explorer: false,
            interactor: false,
            master: false
        };
        this.sectionsVisited = new Set();
        this.interactionCount = 0;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initThreeJS();
        this.initMatrixRain();
        this.initTypingGame();
        this.initAnimations();
        this.setupIntersectionObserver();
        this.initCustomCursor();
        this.initParticleEffects();
    }

    setupEventListeners() {
        // Navigation tracking
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                const section = e.target.getAttribute('data-section');
                this.visitSection(section);
                this.addXP(10);
                this.createParticleExplosion(e.target);
            });
        });

        // Interactive elements
        document.querySelectorAll('.interactive-element').forEach(element => {
            element.addEventListener('click', (e) => {
                this.handleInteraction(e);
                this.addXP(5);
                this.interactionCount++;
                this.checkAchievements();
            });
        });

        // Skill orbs
        document.querySelectorAll('.skill-orb').forEach(orb => {
            orb.addEventListener('click', (e) => {
                this.activateSkillOrb(e.target);
                this.addXP(15);
            });
        });

        // Project cards
        document.querySelectorAll('.interactive-project-card').forEach(card => {
            card.addEventListener('mouseenter', (e) => {
                this.activateProjectCard(e.currentTarget);
            });
        });

        // Certificate cards
        document.querySelectorAll('.interactive-cert-card').forEach(card => {
            card.addEventListener('mouseenter', (e) => {
                this.activateCertCard(e.currentTarget);
            });
        });

        // 3D cubes
        document.querySelectorAll('.interactive-3d').forEach(cube => {
            cube.addEventListener('click', (e) => {
                this.rotateCube(e.currentTarget);
                this.addXP(20);
            });
        });
    }

    initThreeJS() {
        // Hero section 3D scene
        this.initHeroScene();
        // Skills section 3D scene
        this.initSkillsScene();
        // Contact section 3D scene
        this.initContactScene();
    }

    initHeroScene() {
        const canvas = document.getElementById('hero-canvas');
        if (!canvas) return;

        this.heroScene = new THREE.Scene();
        this.heroCamera = new THREE.PerspectiveCamera(75, canvas.clientWidth / canvas.clientHeight, 0.1, 1000);
        this.heroRenderer = new THREE.WebGLRenderer({ canvas, alpha: true });
        this.heroRenderer.setSize(canvas.clientWidth, canvas.clientHeight);

        // Create floating geometric objects
        this.createFloatingObjects();

        // Lighting
        const ambientLight = new THREE.AmbientLight(0x64ffda, 0.6);
        this.heroScene.add(ambientLight);

        const pointLight = new THREE.PointLight(0x64ffda, 1, 100);
        pointLight.position.set(10, 10, 10);
        this.heroScene.add(pointLight);

        this.heroCamera.position.z = 5;

        // Animation loop
        this.animateHeroScene();
    }

    createFloatingObjects() {
        const geometries = [
            new THREE.BoxGeometry(0.5, 0.5, 0.5),
            new THREE.SphereGeometry(0.3, 16, 16),
            new THREE.ConeGeometry(0.3, 0.6, 8),
            new THREE.OctahedronGeometry(0.4),
            new THREE.TetrahedronGeometry(0.4)
        ];

        const material = new THREE.MeshPhongMaterial({
            color: 0x64ffda,
            wireframe: true,
            transparent: true,
            opacity: 0.8
        });

        this.floatingObjects = [];

        for (let i = 0; i < 15; i++) {
            const geometry = geometries[Math.floor(Math.random() * geometries.length)];
            const mesh = new THREE.Mesh(geometry, material);
            
            mesh.position.set(
                (Math.random() - 0.5) * 10,
                (Math.random() - 0.5) * 10,
                (Math.random() - 0.5) * 10
            );
            
            mesh.rotation.set(
                Math.random() * Math.PI,
                Math.random() * Math.PI,
                Math.random() * Math.PI
            );

            mesh.userData = {
                rotationSpeed: {
                    x: (Math.random() - 0.5) * 0.02,
                    y: (Math.random() - 0.5) * 0.02,
                    z: (Math.random() - 0.5) * 0.02
                },
                floatSpeed: Math.random() * 0.01 + 0.005
            };

            this.heroScene.add(mesh);
            this.floatingObjects.push(mesh);
        }
    }

    animateHeroScene() {
        requestAnimationFrame(() => this.animateHeroScene());

        // Animate floating objects
        this.floatingObjects.forEach((obj, index) => {
            obj.rotation.x += obj.userData.rotationSpeed.x;
            obj.rotation.y += obj.userData.rotationSpeed.y;
            obj.rotation.z += obj.userData.rotationSpeed.z;
            
            obj.position.y += Math.sin(Date.now() * obj.userData.floatSpeed + index) * 0.001;
        });

        this.heroRenderer.render(this.heroScene, this.heroCamera);
    }

    initSkillsScene() {
        const canvas = document.getElementById('skills-canvas');
        if (!canvas) return;

        this.skillsScene = new THREE.Scene();
        this.skillsCamera = new THREE.PerspectiveCamera(75, canvas.clientWidth / canvas.clientHeight, 0.1, 1000);
        this.skillsRenderer = new THREE.WebGLRenderer({ canvas, alpha: true });
        this.skillsRenderer.setSize(canvas.clientWidth, canvas.clientHeight);

        // Create skill constellation
        this.createSkillConstellation();

        this.skillsCamera.position.z = 5;
        this.animateSkillsScene();
    }

    createSkillConstellation() {
        const skills = ['JS', 'PY', 'JAVA', 'C++', 'REACT', 'NODE'];
        this.skillNodes = [];

        skills.forEach((skill, index) => {
            const geometry = new THREE.SphereGeometry(0.2, 16, 16);
            const material = new THREE.MeshPhongMaterial({
                color: 0x64ffda,
                emissive: 0x64ffda,
                emissiveIntensity: 0.3
            });

            const sphere = new THREE.Mesh(geometry, material);
            const angle = (index / skills.length) * Math.PI * 2;
            const radius = 2;

            sphere.position.set(
                Math.cos(angle) * radius,
                Math.sin(angle) * radius,
                0
            );

            this.skillsScene.add(sphere);
            this.skillNodes.push(sphere);
        });

        // Add connecting lines
        this.createSkillConnections();

        // Lighting
        const ambientLight = new THREE.AmbientLight(0x64ffda, 0.4);
        this.skillsScene.add(ambientLight);
    }

    createSkillConnections() {
        const material = new THREE.LineBasicMaterial({ color: 0x64ffda, transparent: true, opacity: 0.3 });

        for (let i = 0; i < this.skillNodes.length; i++) {
            for (let j = i + 1; j < this.skillNodes.length; j++) {
                const geometry = new THREE.BufferGeometry().setFromPoints([
                    this.skillNodes[i].position,
                    this.skillNodes[j].position
                ]);

                const line = new THREE.Line(geometry, material);
                this.skillsScene.add(line);
            }
        }
    }

    animateSkillsScene() {
        requestAnimationFrame(() => this.animateSkillsScene());

        // Rotate skill constellation
        this.skillNodes.forEach((node, index) => {
            const time = Date.now() * 0.001;
            const angle = (index / this.skillNodes.length) * Math.PI * 2 + time * 0.5;
            const radius = 2;

            node.position.x = Math.cos(angle) * radius;
            node.position.y = Math.sin(angle) * radius;
        });

        this.skillsRenderer.render(this.skillsScene, this.skillsCamera);
    }

    initContactScene() {
        const canvas = document.getElementById('contact-canvas');
        if (!canvas) return;

        this.contactScene = new THREE.Scene();
        this.contactCamera = new THREE.PerspectiveCamera(75, canvas.clientWidth / canvas.clientHeight, 0.1, 1000);
        this.contactRenderer = new THREE.WebGLRenderer({ canvas, alpha: true });
        this.contactRenderer.setSize(canvas.clientWidth, canvas.clientHeight);

        // Create communication network
        this.createNetworkVisualization();

        this.contactCamera.position.z = 5;
        this.animateContactScene();
    }

    createNetworkVisualization() {
        // Create network nodes
        const nodeGeometry = new THREE.SphereGeometry(0.1, 8, 8);
        const nodeMaterial = new THREE.MeshPhongMaterial({ color: 0x64ffda });

        this.networkNodes = [];
        for (let i = 0; i < 20; i++) {
            const node = new THREE.Mesh(nodeGeometry, nodeMaterial);
            node.position.set(
                (Math.random() - 0.5) * 6,
                (Math.random() - 0.5) * 6,
                (Math.random() - 0.5) * 2
            );
            this.contactScene.add(node);
            this.networkNodes.push(node);
        }

        // Create connections
        this.createNetworkConnections();

        // Lighting
        const ambientLight = new THREE.AmbientLight(0x64ffda, 0.6);
        this.contactScene.add(ambientLight);
    }

    createNetworkConnections() {
        const material = new THREE.LineBasicMaterial({ 
            color: 0x64ffda, 
            transparent: true, 
            opacity: 0.2 
        });

        this.networkNodes.forEach((node, i) => {
            // Connect to 2-3 random other nodes
            const connections = Math.floor(Math.random() * 2) + 2;
            for (let j = 0; j < connections; j++) {
                const targetIndex = Math.floor(Math.random() * this.networkNodes.length);
                if (targetIndex !== i) {
                    const geometry = new THREE.BufferGeometry().setFromPoints([
                        node.position,
                        this.networkNodes[targetIndex].position
                    ]);

                    const line = new THREE.Line(geometry, material);
                    this.contactScene.add(line);
                }
            }
        });
    }

    animateContactScene() {
        requestAnimationFrame(() => this.animateContactScene());

        // Animate network nodes
        this.networkNodes.forEach((node, index) => {
            const time = Date.now() * 0.001;
            node.position.y += Math.sin(time + index) * 0.002;
            node.rotation.y += 0.01;
        });

        this.contactRenderer.render(this.contactScene, this.contactCamera);
    }

    initMatrixRain() {
        const canvas = document.getElementById('matrixCanvas');
        const ctx = canvas.getContext('2d');

        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        const matrix = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789@#$%^&*()*&^%+-/~{[|`]}";
        const matrixArray = matrix.split("");

        const fontSize = 10;
        const columns = canvas.width / fontSize;

        const drops = [];
        for (let x = 0; x < columns; x++) {
            drops[x] = 1;
        }

        const drawMatrix = () => {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.04)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            ctx.fillStyle = '#64ffda';
            ctx.font = fontSize + 'px monospace';

            for (let i = 0; i < drops.length; i++) {
                const text = matrixArray[Math.floor(Math.random() * matrixArray.length)];
                ctx.fillText(text, i * fontSize, drops[i] * fontSize);

                if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
                    drops[i] = 0;
                }
                drops[i]++;
            }
        };

        setInterval(drawMatrix, 35);

        // Resize handler
        window.addEventListener('resize', () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        });
    }

    initTypingGame() {
        const codeSnippets = [
            "console.log('Hello, World!');",
            "function fibonacci(n) { return n <= 1 ? n : fibonacci(n-1) + fibonacci(n-2); }",
            "const arr = [1, 2, 3].map(x => x * 2);",
            "import React from 'react';",
            "def quicksort(arr): return arr if len(arr) <= 1 else quicksort([x for x in arr[1:] if x < arr[0]]) + [arr[0]] + quicksort([x for x in arr[1:] if x >= arr[0]])",
            "SELECT * FROM users WHERE age > 18;",
            "git commit -m 'Initial commit'",
            "npm install react three gsap"
        ];

        let currentSnippet = '';
        let startTime = 0;
        let gameActive = false;

        const codeDisplay = document.getElementById('codeDisplay');
        const codeInput = document.getElementById('codeInput');
        const startButton = document.getElementById('startGame');
        const wpmDisplay = document.getElementById('wpm');
        const accuracyDisplay = document.getElementById('accuracy');
        const scoreDisplay = document.getElementById('gameScore');

        startButton.addEventListener('click', () => {
            if (!gameActive) {
                startGame();
            }
        });

        codeInput.addEventListener('input', (e) => {
            if (gameActive) {
                checkProgress();
            }
        });

        const startGame = () => {
            gameActive = true;
            currentSnippet = codeSnippets[Math.floor(Math.random() * codeSnippets.length)];
            codeDisplay.textContent = currentSnippet;
            codeInput.value = '';
            codeInput.disabled = false;
            codeInput.focus();
            startTime = Date.now();
            startButton.textContent = 'Playing...';
            startButton.disabled = true;
        };

        const checkProgress = () => {
            const typed = codeInput.value;
            const target = currentSnippet;

            // Calculate accuracy
            let correct = 0;
            for (let i = 0; i < typed.length; i++) {
                if (typed[i] === target[i]) {
                    correct++;
                }
            }
            const accuracy = typed.length > 0 ? Math.round((correct / typed.length) * 100) : 100;
            accuracyDisplay.textContent = accuracy + '%';

            // Calculate WPM
            const timeElapsed = (Date.now() - startTime) / 1000 / 60; // minutes
            const wordsTyped = typed.length / 5; // standard word length
            const wpm = timeElapsed > 0 ? Math.round(wordsTyped / timeElapsed) : 0;
            wpmDisplay.textContent = wpm;

            // Update display with correct/incorrect highlighting
            let displayHTML = '';
            for (let i = 0; i < target.length; i++) {
                if (i < typed.length) {
                    if (typed[i] === target[i]) {
                        displayHTML += `<span style="color: #64ffda;">${target[i]}</span>`;
                    } else {
                        displayHTML += `<span style="color: #ff6b6b; background: rgba(255,107,107,0.2);">${target[i]}</span>`;
                    }
                } else {
                    displayHTML += target[i];
                }
            }
            codeDisplay.innerHTML = displayHTML;

            // Check completion
            if (typed === target) {
                endGame(wpm, accuracy);
            }
        };

        const endGame = (wpm, accuracy) => {
            gameActive = false;
            codeInput.disabled = true;
            startButton.textContent = 'Start Challenge';
            startButton.disabled = false;

            const score = Math.round(wpm * (accuracy / 100) * 10);
            scoreDisplay.textContent = score;

            this.addXP(score);
            this.showAchievement('Code Master!', 'Completed typing challenge');

            // Particle explosion effect
            this.createParticleExplosion(startButton);
        };
    }

    initAnimations() {
        // GSAP animations for various elements
        gsap.registerPlugin();

        // Animate hero text
        gsap.timeline()
            .from('.hero-greeting', { duration: 1, y: 50, opacity: 0, ease: 'power2.out' })
            .from('.hero-name', { duration: 1, y: 50, opacity: 0, ease: 'power2.out' }, '-=0.5')
            .from('.hero-subtitle', { duration: 1, y: 30, opacity: 0, ease: 'power2.out' }, '-=0.3')
            .from('.hero-buttons .btn', { duration: 0.8, y: 30, opacity: 0, stagger: 0.2, ease: 'power2.out' }, '-=0.3');

        // Animate skill bars on scroll
        this.animateSkillBars();

        // Animate stats counters
        this.animateStatsCounters();
    }

    animateSkillBars() {
        const skillBars = document.querySelectorAll('.skill-progress');
        
        skillBars.forEach(bar => {
            const width = bar.getAttribute('data-width');
            gsap.set(bar, { width: '0%' });
            
            gsap.to(bar, {
                width: width,
                duration: 2,
                ease: 'power2.out',
                scrollTrigger: {
                    trigger: bar,
                    start: 'top 80%',
                    toggleActions: 'play none none reverse'
                }
            });
        });
    }

    animateStatsCounters() {
        const stats = document.querySelectorAll('.interactive-stat');
        
        stats.forEach(stat => {
            const target = parseFloat(stat.getAttribute('data-target'));
            const counter = stat.querySelector('.stat-number');
            
            gsap.to({ value: 0 }, {
                value: target,
                duration: 2,
                ease: 'power2.out',
                onUpdate: function() {
                    counter.textContent = this.targets()[0].value.toFixed(target % 1 === 0 ? 0 : 2);
                },
                scrollTrigger: {
                    trigger: stat,
                    start: 'top 80%',
                    toggleActions: 'play none none reverse'
                }
            });
        });
    }

    setupIntersectionObserver() {
        const sections = document.querySelectorAll('section[data-section]');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const sectionName = entry.target.getAttribute('data-section');
                    this.visitSection(sectionName);
                    
                    // Add section-specific animations
                    this.triggerSectionAnimations(entry.target);
                }
            });
        }, { threshold: 0.3 });

        sections.forEach(section => observer.observe(section));
    }

    triggerSectionAnimations(section) {
        const sectionClass = section.className;
        
        // Animate elements based on section
        if (sectionClass.includes('about')) {
            gsap.from(section.querySelectorAll('.detail-item'), {
                duration: 1,
                y: 50,
                opacity: 0,
                stagger: 0.2,
                ease: 'power2.out'
            });
        }
        
        if (sectionClass.includes('projects')) {
            gsap.from(section.querySelectorAll('.project-card'), {
                duration: 1,
                scale: 0.8,
                opacity: 0,
                stagger: 0.1,
                ease: 'back.out(1.7)'
            });
        }
        
        if (sectionClass.includes('certifications')) {
            gsap.from(section.querySelectorAll('.cert-card'), {
                duration: 1,
                rotationY: 90,
                opacity: 0,
                stagger: 0.1,
                ease: 'power2.out'
            });
        }
    }

    initCustomCursor() {
        const cursor = document.querySelector('.cursor');
        const follower = document.querySelector('.cursor-follower');

        let mouseX = 0, mouseY = 0;
        let followerX = 0, followerY = 0;

        document.addEventListener('mousemove', (e) => {
            mouseX = e.clientX;
            mouseY = e.clientY;
            
            cursor.style.left = mouseX + 'px';
            cursor.style.top = mouseY + 'px';
        });

        // Smooth follower animation
        const animateFollower = () => {
            followerX += (mouseX - followerX) * 0.1;
            followerY += (mouseY - followerY) * 0.1;
            
            follower.style.left = followerX + 'px';
            follower.style.top = followerY + 'px';
            
            requestAnimationFrame(animateFollower);
        };
        animateFollower();

        // Cursor interactions
        document.querySelectorAll('.interactive-element, .interactive-btn, .nav-link').forEach(element => {
            element.addEventListener('mouseenter', () => {
                cursor.style.transform = 'translate(-50%, -50%) scale(1.5)';
                follower.style.transform = 'translate(-50%, -50%) scale(1.5)';
            });
            
            element.addEventListener('mouseleave', () => {
                cursor.style.transform = 'translate(-50%, -50%) scale(1)';
                follower.style.transform = 'translate(-50%, -50%) scale(1)';
            });
        });
    }

    initParticleEffects() {
        // Initialize particle systems for various interactions
        this.particleSystem = {
            particles: [],
            maxParticles: 100
        };
    }

    // Game mechanics
    visitSection(sectionName) {
        if (!this.sectionsVisited.has(sectionName)) {
            this.sectionsVisited.add(sectionName);
            this.addXP(25);
            this.updateExplorationProgress();
            this.checkAchievements();
        }
    }

    addXP(amount) {
        this.xp += amount;
        document.getElementById('xpScore').textContent = this.xp;
        
        // Animate XP gain
        gsap.from('#xpScore', {
            duration: 0.5,
            scale: 1.3,
            color: '#64ffda',
            ease: 'back.out(1.7)'
        });
    }

    updateExplorationProgress() {
        const totalSections = 7; // home, about, skills, experience, projects, certifications, contact
        this.explorationProgress = (this.sectionsVisited.size / totalSections) * 100;
        
        const progressBar = document.getElementById('explorationProgress');
        const progressText = progressBar.nextElementSibling;
        
        gsap.to(progressBar, {
            duration: 1,
            width: this.explorationProgress + '%',
            ease: 'power2.out'
        });
        
        progressText.textContent = Math.round(this.explorationProgress) + '%';
    }

    checkAchievements() {
        // Explorer achievement
        if (this.sectionsVisited.size >= 3 && !this.achievements.explorer) {
            this.unlockAchievement('explorer', 'Explorer', 'Visited 3 sections');
        }
        
        // Interactor achievement
        if (this.interactionCount >= 10 && !this.achievements.interactor) {
            this.unlockAchievement('interactor', 'Interactor', 'Made 10 interactions');
        }
        
        // Master achievement
        if (this.explorationProgress >= 100 && this.xp >= 200 && !this.achievements.master) {
            this.unlockAchievement('master', 'Master', 'Fully explored portfolio');
        }
    }

    unlockAchievement(id, title, description) {
        this.achievements[id] = true;
        
        const badge = document.getElementById(id + 'Badge');
        badge.classList.add('unlocked');
        
        this.showAchievement(title, description);
        this.addXP(50);
    }

    showAchievement(title, description) {
        const notification = document.getElementById('achievementNotification');
        const icon = notification.querySelector('.achievement-icon');
        const text = notification.querySelector('.achievement-text');
        
        icon.innerHTML = '<i class="fas fa-trophy"></i>';
        text.innerHTML = `<strong>${title}</strong><br>${description}`;
        
        notification.classList.add('show');
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }

    // Interactive element handlers
    handleInteraction(event) {
        this.createRippleEffect(event.target, event);
        this.createParticleExplosion(event.target);
    }

    createRippleEffect(element, event) {
        const ripple = document.createElement('div');
        ripple.className = 'ripple-effect';
        
        const rect = element.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = event.clientX - rect.left - size / 2;
        const y = event.clientY - rect.top - size / 2;
        
        ripple.style.width = ripple.style.height = size + 'px';
        ripple.style.left = x + 'px';
        ripple.style.top = y + 'px';
        
        element.appendChild(ripple);
        
        setTimeout(() => {
            ripple.remove();
        }, 1000);
    }

    createParticleExplosion(element) {
        const rect = element.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        
        for (let i = 0; i < 10; i++) {
            const particle = document.createElement('div');
            particle.className = 'explosion-particle';
            particle.style.left = centerX + 'px';
            particle.style.top = centerY + 'px';
            
            document.body.appendChild(particle);
            
            const angle = (Math.PI * 2 * i) / 10;
            const velocity = 100 + Math.random() * 50;
            const lifetime = 1000 + Math.random() * 500;
            
            gsap.to(particle, {
                duration: lifetime / 1000,
                x: Math.cos(angle) * velocity,
                y: Math.sin(angle) * velocity,
                opacity: 0,
                scale: 0,
                ease: 'power2.out',
                onComplete: () => particle.remove()
            });
        }
    }

    activateSkillOrb(orb) {
        const level = orb.getAttribute('data-level');
        
        gsap.timeline()
            .to(orb, { duration: 0.3, scale: 1.5, ease: 'back.out(1.7)' })
            .to(orb, { duration: 0.3, scale: 1, ease: 'back.out(1.7)' });
        
        // Show skill level tooltip
        this.showTooltip(orb, `Skill Level: ${level}%`);
    }

    activateProjectCard(card) {
        const overlay = card.querySelector('.project-overlay');
        const glow = card.querySelector('.project-glow');
        
        gsap.to(overlay, { duration: 0.3, opacity: 1 });
        gsap.to(glow, { duration: 0.3, opacity: 1 });
        gsap.to(card, { duration: 0.3, y: -10, ease: 'power2.out' });
        
        card.addEventListener('mouseleave', () => {
            gsap.to(overlay, { duration: 0.3, opacity: 0 });
            gsap.to(glow, { duration: 0.3, opacity: 0 });
            gsap.to(card, { duration: 0.3, y: 0, ease: 'power2.out' });
        }, { once: true });
    }

    activateCertCard(card) {
        const glow = card.querySelector('.cert-glow');
        const particles = card.querySelector('.cert-particles');
        
        gsap.to(card, { duration: 0.3, rotationY: 5, scale: 1.05, ease: 'power2.out' });
        gsap.to(glow, { duration: 0.3, opacity: 1 });
        
        card.addEventListener('mouseleave', () => {
            gsap.to(card, { duration: 0.3, rotationY: 0, scale: 1, ease: 'power2.out' });
            gsap.to(glow, { duration: 0.3, opacity: 0 });
        }, { once: true });
    }

    rotateCube(cube) {
        const currentRotation = cube.style.transform || 'rotateX(0deg) rotateY(0deg)';
        const newRotationY = Math.random() * 360;
        const newRotationX = Math.random() * 360;
        
        gsap.to(cube, {
            duration: 1,
            rotationX: newRotationX,
            rotationY: newRotationY,
            ease: 'power2.out'
        });
        
        this.createParticleExplosion(cube);
    }

    showTooltip(element, text) {
        const tooltip = document.createElement('div');
        tooltip.className = 'game-tooltip';
        tooltip.textContent = text;
        
        const rect = element.getBoundingClientRect();
        tooltip.style.left = rect.left + rect.width / 2 + 'px';
        tooltip.style.top = rect.top - 40 + 'px';
        
        document.body.appendChild(tooltip);
        
        gsap.from(tooltip, { duration: 0.3, opacity: 0, y: 10 });
        
        setTimeout(() => {
            gsap.to(tooltip, { 
                duration: 0.3, 
                opacity: 0, 
                y: -10,
                onComplete: () => tooltip.remove()
            });
        }, 2000);
    }
}

// Utility functions
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
    }
}

// Initialize the game when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.gamePortfolio = new GamePortfolio();
});

// Handle window resize
window.addEventListener('resize', () => {
    if (window.gamePortfolio) {
        // Resize Three.js renderers
        const heroCanvas = document.getElementById('hero-canvas');
        const skillsCanvas = document.getElementById('skills-canvas');
        const contactCanvas = document.getElementById('contact-canvas');
        
        if (heroCanvas && window.gamePortfolio.heroRenderer) {
            window.gamePortfolio.heroRenderer.setSize(heroCanvas.clientWidth, heroCanvas.clientHeight);
            window.gamePortfolio.heroCamera.aspect = heroCanvas.clientWidth / heroCanvas.clientHeight;
            window.gamePortfolio.heroCamera.updateProjectionMatrix();
        }
        
        if (skillsCanvas && window.gamePortfolio.skillsRenderer) {
            window.gamePortfolio.skillsRenderer.setSize(skillsCanvas.clientWidth, skillsCanvas.clientHeight);
            window.gamePortfolio.skillsCamera.aspect = skillsCanvas.clientWidth / skillsCanvas.clientHeight;
            window.gamePortfolio.skillsCamera.updateProjectionMatrix();
        }
        
        if (contactCanvas && window.gamePortfolio.contactRenderer) {
            window.gamePortfolio.contactRenderer.setSize(contactCanvas.clientWidth, contactCanvas.clientHeight);
            window.gamePortfolio.contactCamera.aspect = contactCanvas.clientWidth / contactCanvas.clientHeight;
            window.gamePortfolio.contactCamera.updateProjectionMatrix();
        }
    }
});

// Add CSS for dynamic effects
const dynamicStyles = `
.ripple-effect {
    position: absolute;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(100, 255, 218, 0.6) 0%, transparent 70%);
    transform: scale(0);
    animation: ripple 1s ease-out;
    pointer-events: none;
    z-index: 1000;
}

@keyframes ripple {
    to {
        transform: scale(2);
        opacity: 0;
    }
}

.explosion-particle {
    position: fixed;
    width: 4px;
    height: 4px;
    background: #64ffda;
    border-radius: 50%;
    pointer-events: none;
    z-index: 1000;
}

.game-tooltip {
    position: fixed;
    background: rgba(100, 255, 218, 0.9);
    color: #000;
    padding: 8px 12px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 600;
    pointer-events: none;
    z-index: 1000;
    transform: translateX(-50%);
}
`;

// Inject dynamic styles
const styleSheet = document.createElement('style');
styleSheet.textContent = dynamicStyles;
document.head.appendChild(styleSheet);

